/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include "pico/stdlib.h"
#include "pico/binary_info.h"
#include "hardware/i2c.h"
#include "MedianFilter.h"
#include "MedianFilter.c"

#include "math.h"
#define NUM_ELEMENTS    7

static sMedianFilter_t medianFilter;
static sMedianNode_t medianBuffer[NUM_ELEMENTS];
// By default these devices  are on bus address 0x68
static int addr = 0x68;

#ifdef i2c_default
static void mpu6050_reset() {
    // Two byte reset. First byte register, second byte data
    uint8_t buf[] = {0x6B, 0x00};
    i2c_write_blocking(i2c_default, addr, buf, 2, false);
}

static void mpu6050_read_raw(int16_t accel[3], int16_t gyro[3], int16_t *temp) {

    uint8_t buffer[6];
    // Start reading acceleration registers from register 0x3B for 6 bytes
    uint8_t val = 0x3B;
    i2c_write_blocking(i2c_default, addr, &val, 1, true); // true to keep master control of bus
    i2c_read_blocking(i2c_default, addr, buffer, 6, false);

    for (int i = 0; i < 3; i++) {
        accel[i] = (buffer[i * 2] << 8 | buffer[(i * 2) + 1]);
    }

    // Now gyro data from reg 0x43 for 6 bytes
    // The register is auto incrementing on each read
    val = 0x43;
    i2c_write_blocking(i2c_default, addr, &val, 1, true);
    i2c_read_blocking(i2c_default, addr, buffer, 6, false);  // False - finished with bus

    for (int i = 0; i < 3; i++) {
        gyro[i] = (buffer[i * 2] << 8 | buffer[(i * 2) + 1]);;
    }

    // Now temperature from reg 0x41 for 2 bytes
    // The register is auto incrementing on each read
    val = 0x41;
    i2c_write_blocking(i2c_default, addr, &val, 1, true);
    i2c_read_blocking(i2c_default, addr, buffer, 2, false);  // False - finished with bus

    *temp = buffer[0] << 8 | buffer[1];
}
#endif
#define MAX_INPUT_LEN   80
// maximum length of filter than can be handled
#define MAX_FLT_LEN     63
// buffer to hold all of the input samples
#define BUFFER_LEN      (MAX_FLT_LEN - 1 + MAX_INPUT_LEN)
 
// array to hold input samples
double insamp[ BUFFER_LEN ];
 
//Variables for the kalman Filter
float xData, original ,originalX, data1, data2,temp;
float originalX,newX, temp,temp2,difference,distance;
float Xt, Xt_update, Xt_prev;
float Pt, Pt_update, Pt_prev = 1;
float Kt, R = 100, Q = 1;
int counter;
//Declarations for the functions
int checkHump(float original, float newX);
int SMA(float original);
int movingAvg(int *ptrArrNumbers, long *ptrSum, int pos, int len, int nextNum);
float kalmanFilter(float distance);
int main() {
    //Counter for testing purposes
    counter = 0;
    stdio_init_all();
    // This example will use I2C0 on the default SDA and SCL pins (4, 5 on a Pico) 
    // SDA: GPIO PIN4
    // SCL: GPIO PIN5
    i2c_init(i2c_default, 40 * 1000);
    medianFilter.numNodes = NUM_ELEMENTS;
    medianFilter.medianBuffer = medianBuffer;
    MEDIANFILTER_Init(&medianFilter);
    // Make the I2C pins available to picotool
    bi_decl(bi_2pins_with_func(PICO_DEFAULT_I2C_SDA_PIN, PICO_DEFAULT_I2C_SCL_PIN, GPIO_FUNC_I2C));
    mpu6050_reset();
    int16_t acceleration[3], gyro[3], temp;
    mpu6050_read_raw(acceleration, gyro, &temp);
    originalX = acceleration[0];
    while (1) {
        counter++;
        mpu6050_read_raw(acceleration, gyro, &temp);
        //Kalman Filter
        original = (float) acceleration[0];
        xData = kalmanFilter(original);
        data2 = original;
        int medianValue = MEDIANFILTER_Insert(&medianFilter, data2);
        data1 = SMA(original); //Gets the SMA filter
        newX = (float) acceleration[0];
          if(counter < 300) {
              printf("%f %f %f %d %d \n",original,xData,data1,medianValue,counter);
           } 
        if(checkHump(originalX,newX) == 1){
            mpu6050_read_raw(acceleration, gyro, &temp);
            temp = acceleration[0];
            if (temp > newX){
                newX = temp;
            }
        }   
        if((originalX + 1000) < newX){
         if(checkHump(originalX,newX) == 1){
            difference = newX- original;
            distance = tan(difference) * 1.5;
            if (distance >1 && distance < 10){
              //  printf("Height of Hump: %f \n",distance);
            }
        }
        }
        sleep_ms(100);
    }

    return 0;
}



float kalmanFilter(float distance){
        Xt_update = Xt_prev;
        Pt_update = Pt_prev + Q;
        Kt = Pt_update / (Pt_update + R);
        Xt = Xt_update + ( Kt * (distance - Xt_update));
        Pt = (1 - Kt) * Pt_update;
        Xt_prev = Xt;
        Pt_prev = Pt;
        xData=Xt;
        return xData;
}


int checkHump(float original, float newX){
    if(newX > (original + 1000)){
        return 1;
    }
    else{
        return 0;
    }
}

int SMA(float original)
{
    int newAvg =0;
    int pos = 0;
    int i = 0;
    long sum = 0;
    int arrNumbers[5] = { 0 };
    int len = sizeof(arrNumbers) / sizeof(int);

    newAvg = movingAvg(arrNumbers, &sum, pos, len, original);
    pos++;
    if (pos >= len)
    {
        pos = 0;

    }
    return newAvg;
}

int movingAvg(int *ptrArrNumbers, long *ptrSum, int pos, int len, int nextNum)
{

    //Subtract the oldest number from the prev sum, add the new number

    *ptrSum = *ptrSum - ptrArrNumbers[pos] + nextNum;

    //Assign the nextNum to the position in the array

    ptrArrNumbers[pos] = nextNum;

    //return the average

    return *ptrSum / len;

}