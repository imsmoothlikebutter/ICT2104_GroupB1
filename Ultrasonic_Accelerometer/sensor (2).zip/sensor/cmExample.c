//This example uses the ultrasonic script to get centimeters and writes it to UART

#include "pico/stdlib.h"
#include <stdio.h>
#include "ultrasonic.h"
#include "hardware/uart.h"

uint trigPin = 2;
uint echoPin = 3;
float xData, original , data1, data2, data3; 
float Xt, Xt_update, Xt_prev;
float Pt, Pt_update, Pt_prev = 1;
float Kt, R = 100, Q = 1;
int SMA(float original);
int movingAvg(int *ptrArrNumbers, long *ptrSum, int pos, int len, int nextNum);
float kalmanFilter(float distance);

int main()
{
    float distance =0;
    stdio_init_all();
    int counter = 0;
    setupUltrasonicPins(trigPin, echoPin);
    while (true) {
        counter++;
        distance = getCm(trigPin, echoPin);
        xData = kalmanFilter(distance);
        data2 = distance;
        data3 = SMA(distance);
            printf("%f %f %f %d %d\n",distance, xData,data3,counter); 
        
        sleep_ms(100);
    }
}

float kalmanFilter(float distance){
        Xt_update = Xt_prev;
        Pt_update = Pt_prev + Q;
        Kt = Pt_update / (Pt_update + R);
        Xt = Xt_update + ( Kt * (distance - Xt_update));
        Pt = (1 - Kt) * Pt_update;
        Xt_prev = Xt;
        Pt_prev = Pt;
        xData=Xt;
        return xData;
}

/* boolean checkFront(){
distance = getCm(trigPin, echoPin);
if (distance <= 8) {
    frontDetect = true;
    whileTurning = true;
}
else{
    frontDetect = false;
}
}

boolean checkSide(){
    distance = getCm(trigPin, echoPin);
if (distance <= 8) {
    sideDetect = true;
    whileTurning = true;
}
else{
    sideDetect = false;
}

} */

int SMA(float original)
{
    int newAvg =0;
    int pos = 0;
    int i = 0;
    long sum = 0;
    int arrNumbers[5] = { 0 };
    int len = sizeof(arrNumbers) / sizeof(int);

    newAvg = movingAvg(arrNumbers, &sum, pos, len, original);
    pos++;
    if (pos >= len)
    {
        pos = 0;

    }
    return newAvg;
}

int movingAvg(int *ptrArrNumbers, long *ptrSum, int pos, int len, int nextNum)
{

    //Subtract the oldest number from the prev sum, add the new number

    *ptrSum = *ptrSum - ptrArrNumbers[pos] + nextNum;

    //Assign the nextNum to the position in the array

    ptrArrNumbers[pos] = nextNum;

    //return the average

    return *ptrSum / len;

}