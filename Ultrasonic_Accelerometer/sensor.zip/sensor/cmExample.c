//This example uses the ultrasonic script to get centimeters and writes it to UART

#include "pico/stdlib.h"
#include <stdio.h>
#include "ultrasonic.h"
#include "hardware/uart.h"

uint trigPin = 2;
uint echoPin = 3;
float xData, original , data1, data2, data3; 
float Xt, Xt_update, Xt_prev;
float Pt, Pt_update, Pt_prev = 1;
float Kt, R = 100, Q = 1;
float kalmanFilter(float distance);
int main()
{
    float distance =0;
    stdio_init_all();
    int counter = 0;
    setupUltrasonicPins(trigPin, echoPin);
    while (true) {
        counter++;
        distance = getCm(trigPin, echoPin);
        xData = kalmanFilter(distance);
        if (counter < 300){
             printf("%f %d\n",xData,counter); 
        }
        sleep_ms(100);
    }
}

float kalmanFilter(float distance){
        Xt_update = Xt_prev;
        Pt_update = Pt_prev + Q;
        Kt = Pt_update / (Pt_update + R);
        Xt = Xt_update + ( Kt * (distance - Xt_update));
        Pt = (1 - Kt) * Pt_update;
        Xt_prev = Xt;
        Pt_prev = Pt;
        xData=Xt;
        return xData;

}
}