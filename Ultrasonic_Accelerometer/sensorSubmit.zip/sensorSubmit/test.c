#include "msp.h"
#include <stdint.h>
#include "driverlib.h"
#include "stdio.h"

//Minimum Distance and Tick Period
#define TICKPERIOD 1000
#define MIN_DISTANCE 80.0f

//TimerA1 Counter
int miliseconds;

//Sensor 1 Details
int distance = 0;
long sensor = 0;

//Sensor 2 Details
int distance2 = 0;
long sensor2 = 0;

//Used to generate the graph for Testing
int counter = 0;

//Used for the KalmanFilter
float Xt, Xt_update, Xt_prev;
float Pt, Pt_update, Pt_prev;
float Kt, R, Q;

//Used for the SMA Filter
long newAvg;

static void Delay(uint32_t loop)
{
    volatile uint32_t i;

    for (i = 0; i < loop; i++)
        ;
}

void InitaliseUART(void)
{
    const eUSCI_UART_Config uartConfig = {
    EUSCI_A_UART_CLOCKSOURCE_SMCLK,                 // SMCLK Clock Source
            1,                                             // BRDIV = 78
            10,                                              // UCxBRF = 2
            0,                                              // UCxBRS = 0
            EUSCI_A_UART_ODD_PARITY,                        // ODD Parity
            EUSCI_A_UART_LSB_FIRST,                         // LSB First
            EUSCI_A_UART_ONE_STOP_BIT,                      // One stop bit
            EUSCI_A_UART_MODE,                              // UART mode
            EUSCI_A_UART_OVERSAMPLING_BAUDRATE_GENERATION,  // Oversampling
            };
    UART_initModule(EUSCI_A0_BASE, &uartConfig);
    /* Enable UART module */
    UART_enableModule(EUSCI_A0_BASE);
    /* Enabling interrupts (Rx) */
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1,
    GPIO_PIN2 | GPIO_PIN3,
                                               GPIO_PRIMARY_MODULE_FUNCTION);
    UART_enableInterrupt(EUSCI_A0_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
}

void InitaliseSensor(void)
{
    //Set P1.0 LED for testing
    GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN0);
    GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN0);
    //Set Echo Pin P3.7
    GPIO_setAsInputPinWithPullDownResistor(GPIO_PORT_P3, GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN7);
    //Set Trigger Pin P3.6
    GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN6);
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN6);
    //Enable rising edge for Pin P3.7
    P3->IFG = 0;
    P3->IE |= BIT7;
    P3->IES &= ~BIT7;
}
void InitaliseSensor2(void)
{
    //Set P2.0 LED for testing
    GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN0);
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0);
    //Set Echo Pin P2.7
    GPIO_setAsInputPinWithPullDownResistor(GPIO_PORT_P2, GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN7);
    //Set Trigger Pin P2.6
    GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN6);
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN6);
    //Enable rising edge for Pin P2.7
    P2->IFG = 0;
    P2->IE |= BIT7;
    P2->IES &= ~BIT7;
}

void uPrintf(unsigned char * TxArray);

bool checkFront(void)
{
    NVIC->ISER[1] = 1 << ((PORT2_IRQn) & 31);
    //Set a 10 sec us pulse on P2.6
    GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN6);
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN6);
    P2->IES &= ~BIT7;         // rising edge on ECHO pin
    Delay(3000);
    //Used for Outputting
    char* buffer[255];
    //Increment Counter for graph purposes
    counter++;

    //Filtering Algorithm
    //sensor = KalmanFilter(sensor);
    //Prints the Sensor Details + Counter for graph generation

    SMA();
    snprintf(buffer, 255, "%d %d\r\n", newAvg, counter);
    uPrintf(buffer);

    distance = sensor / 58;     // Converting ECHO Length
    if (distance < MIN_DISTANCE && distance != 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
bool checkSide(void)
{
    NVIC->ISER[1] = 1 << ((PORT3_IRQn) & 31);
    //Set a 10 sec us pulse on P3.6
    GPIO_setOutputHighOnPin(GPIO_PORT_P3, GPIO_PIN6);
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN6);
    P3->IES &= ~BIT7;         // rising edge on ECHO pin
    Delay(5000);
    distance2 = sensor2 / 58;   // converting ECHO length
    if (distance2 < MIN_DISTANCE && distance2 != 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}

int main(void)
{
    //Initialize UART
    InitaliseUART();
    //Enable Interrupts
    Interrupt_enableInterrupt(INT_EUSCIA0);
    Interrupt_enableMaster();
    //Initialize HSCR04 Sensor
    InitaliseSensor(); // Echo Pin: P3.7 , Trigger Pin: P3.6, LED PIN: P1.0
    InitaliseSensor2();  // Echo Pin: P2.7 , Trigger Pin: P2.6, LED PIN: P2.0
    //Stops Watchdog Timer
    WDT_A_holdTimer();

    //Variables for the Kalman Filter
    R = 100;
    Q = 1;
    Pt_prev = 1;
    /*          TIMER A0          */
    TIMER_A0->CCTL[0] = TIMER_A_CCTLN_CCIE;       // CCR0 interrupt enabled
    TIMER_A0->CCR[0] = 1000 - 1;                   // 1ms at 1mhz
    TIMER_A0->CTL = TIMER_A_CTL_TASSEL_2 | TIMER_A_CTL_MC__UP | TIMER_A_CTL_CLR; // SMCLK, upmode

    Interrupt_enableMaster();
    NVIC->ISER[0] = 1 << ((TA0_0_IRQn) & 31); // Assign Interrupts to the NVIC vector
    uPrintf("Going to LPM3 \r\n");
    while (1)
    {
        if (checkSide())
            GPIO_setOutputHighOnPin(GPIO_PORT_P1, GPIO_PIN0);
        else
            GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN0);
        if (checkFront())
        {

            GPIO_setOutputHighOnPin(GPIO_PORT_P2, GPIO_PIN0);
        }

        else
            GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0);
    }
}

// Port2 interrupt service routine
void PORT2_IRQHandler(void)
{
    if (P2->IFG & BIT7)  //is there interrupt pending?
    {
        if (!(P2->IES & BIT7 )) // is this the rising edge?
        {
            TIMER_A0->CTL |= TIMER_A_CTL_CLR;   // clears timer A
            miliseconds = 0;
            P2->IES |= BIT7;  //falling edge
        }
        else
        {
            sensor = (long) miliseconds * 1000 + (long) TIMER_A0->R; //calculating ECHO length

            P2->IES &= ~BIT7;  //falling edge
        }
        P2->IFG &= ~BIT7; //clear flag
    }
}

// Port3 interrupt service routine
void PORT3_IRQHandler(void)
{
    if (P3->IFG & BIT7)  //is there interrupt pending?
    {
        if (!(P3->IES & BIT7 )) // is this the rising edge?
        {
            TIMER_A0->CTL |= TIMER_A_CTL_CLR;   // clears timer A
            miliseconds = 0;
            P3->IES |= BIT7;  //falling edge
        }
        else
        {
            sensor2 = (long) miliseconds * 1000 + (long) TIMER_A0->R; //calculating ECHO length
            P3->IES &= ~BIT7;  //falling edge
        }
        P3->IFG &= ~BIT7;             //clear flag
    }
}

void TA0_0_IRQHandler(void)
{
    //    Interrupt gets triggered for every clock cycle in SMCLK Mode counting number of pulses
    miliseconds++;
    TIMER_A0->CCTL[0] &= ~TIMER_A_CCTLN_CCIFG;
}

void uPrintf(unsigned char * TxArray)
{
    unsigned short i = 0;
    while (*(TxArray + i))
    {
        UART_transmitData(EUSCI_A0_BASE, *(TxArray + i)); // Write the character at the location specified by pointer
        i++;                 // Increment pointer to point to the next character
    }
}

long KalmanFilter(long sensor)
{
    Xt_update = Xt_prev;
    Pt_update = Pt_prev + Q;
    Kt = Pt_update / (Pt_update + R);
    Xt = Xt_update + (Kt * (sensor - Xt_update));
    Pt = (1 - Kt) * Pt_update;
    Xt_prev = Xt;
    Pt_prev = Pt;
    sensor = Xt;
    return sensor;
}

void SMA()
{
    int pos = 0;
    int i = 0;
    long sum = 0;
    int arrNumbers[5] = { 0 };
    int len = sizeof(arrNumbers) / sizeof(int);

    newAvg = movingAvg(arrNumbers, &sum, pos, len, sensor);
    pos++;
    if (pos >= len)
    {
        pos = 0;

    }

}

int movingAvg(int *ptrArrNumbers, long *ptrSum, int pos, int len, int nextNum)
{

    //Subtract the oldest number from the prev sum, add the new number

    *ptrSum = *ptrSum - ptrArrNumbers[pos] + nextNum;

    //Assign the nextNum to the position in the array

    ptrArrNumbers[pos] = nextNum;

    //return the average

    return *ptrSum / len;

}

void EUSCIA0_IRQHandler(void)
{
    unsigned char a = 0;
    a = UART_receiveData(EUSCI_A0_BASE);
    UART_transmitData(EUSCI_A0_BASE, a);
}

